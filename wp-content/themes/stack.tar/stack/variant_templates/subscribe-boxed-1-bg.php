<!--META--><section class="vim" id="variant-subscribe-boxed-1-bg" vbr="Subscribe Boxed 1 BG" vbp="subscribes">
<section class="switchable imagebg" data-overlay="4">
    
    <div class="background-image-holder">
        <img alt="background" src="<?php variant_page_builder_demo_img('hero-1.jpg'); ?>">
    </div>
    
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-5">
                <div class="switchable__text wysiwyg">
                    <h2>Premium design backed by<br class="hidden-xs hidden-sm"> friendly support</h2>
                    <p class="lead">
                        Our customers love the comfort that comes with six-months of included support. Our dedicated support forum makes support hassle-free.
                    </p>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="bg--secondary boxed boxed--border boxed--lg cf7-holder">
                	<div class="variant-shortcode vru" data-shortcode-name="contact-form-7" data-param-title="" data-param-id="none">
                		<p class="lead">Manage this form using the section sidebar <i class="material-icons">&#xE5C8;</i></p>
                	</div>
                </div>
            </div>
        </div><!--end of row-->
    </div><!--end of container-->
</section>
</section><!--end of meta Section container-->